import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:vernelly_app/src/pages/sales/sales_controller.dart';

class SalesPage extends StatelessWidget {

  SalesController con = Get.put(SalesController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text('SALES HOME'),
      ),
    );
  }
}
