import 'package:get/get.dart';

class SalesController extends GetxController{

}