import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:vernelly_app/src/pages/contacts/contacts_controller.dart';

class ContactsPage extends StatelessWidget {

  ContactsController con = Get.put(ContactsController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text('CONTACTS HOME'),
      ),
    );
  }
}
