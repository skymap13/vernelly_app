import 'package:get/get.dart';

class ContactsController extends GetxController{

}