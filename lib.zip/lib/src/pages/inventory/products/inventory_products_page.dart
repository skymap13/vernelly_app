import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:vernelly_app/src/models/inventory/products/products_model_data.dart';
import 'dart:io';
import 'package:vernelly_app/src/pages/inventory/products/inventory_products_controller.dart';

class InventoryProductsPage extends StatefulWidget {
  @override
  _InventoryProductsPageState createState() => _InventoryProductsPageState();
}

class _InventoryProductsPageState extends State<InventoryProductsPage> {
  final InventoryController con = Get.put(InventoryController());
  final _formKey = GlobalKey<FormState>();
  final _editFormKey = GlobalKey<FormState>();
  File? _image;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Gestión de Productos',
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.purpleAccent,
      ),
      body: Obx(() {
        if (con.isLoading.value) {
          return Center(child: CircularProgressIndicator());
        } else if (con.filteredProducts.isEmpty) {
          print('Filtered Products: ${con.filteredProducts}');  // Añade esta línea para imprimir los productos filtrados
          return Center(child: Text('No se encontraron productos.'));
        } else {
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextField(
                  onChanged: con.updateSearchQuery,
                  decoration: InputDecoration(
                    hintText: 'Buscar...',
                    prefixIcon: Icon(Icons.search),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ),
              Expanded(
                child: RefreshIndicator(
                  onRefresh: con.fetchProducts,
                  child: ListView.builder(
                    itemCount: con.filteredProducts.length,
                    itemBuilder: (context, index) {
                      final product = con.filteredProducts[index];
                      return ListTile(
                        title: Text(product.nombre ?? 'Nombre no disponible'),
                        subtitle: Text('Precio: \$${product.precio?.toString() ?? 'N/A'}'),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            _buildActionButton(
                              icon: Icons.edit,
                              color: Colors.blue,
                              onPressed: () => _showEditProductDialog(context, product),
                            ),
                            SizedBox(width: 8),
                            _buildActionButton(
                              icon: product.estado == 'ACTIVO' ? Icons.remove_circle : Icons.add_circle,
                              color: product.estado == 'ACTIVO' ? Colors.red : Colors.green,
                              onPressed: () {
                                if (product.estado == 'ACTIVO') {
                                  _showConfirmationDialog(
                                    context,
                                    'Desactivar producto',
                                    '¿Desea desactivar este producto?',
                                        () => con.deactivateProduct(context, product),
                                  );
                                } else {
                                  _showConfirmationDialog(
                                    context,
                                    'Activar producto',
                                    '¿Desea activar este producto?',
                                        () => con.activateProduct(context, product),
                                  );
                                }
                              },
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ),
            ],
          );
        }
      }),
      bottomNavigationBar: BottomAppBar(
        color: Colors.purpleAccent,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () => _showAddProductDialog(context, con),
                  icon: Icon(Icons.add),
                  label: Text('Agregar Producto'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.purpleAccent,
                  ),
                ),
              ),
              SizedBox(width: 8),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () => con.downloadReport(),
                  icon: Icon(Icons.download),
                  label: Text('Descargar Reporte'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.purpleAccent,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildActionButton({required IconData icon, required Color color, required VoidCallback onPressed}) {
    return Container(
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: Colors.black26,
            blurRadius: 4,
            offset: Offset(2, 2),
          ),
        ],
      ),
      child: IconButton(
        icon: Icon(icon, color: Colors.white),
        onPressed: onPressed,
      ),
    );
  }

  void _showConfirmationDialog(BuildContext context, String title, String content, VoidCallback onConfirm) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            title,
            style: TextStyle(
              color: Colors.purpleAccent,
              fontWeight: FontWeight.bold,
            ),
          ),
          content: Text(content),
          actions: <Widget>[
            TextButton(
              child: Text(
                'CANCELAR',
                style: TextStyle(color: Colors.purpleAccent),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text(
                'ACEPTAR',
                style: TextStyle(color: Colors.purpleAccent),
              ),
              onPressed: () {
                Navigator.of(context).pop();
                onConfirm();
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> _pickImage(BuildContext context, StateSetter setState) async {
    final pickedFile = await showDialog<File>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Seleccionar imagen'),
        content: Text('Elige una fuente'),
        actions: [
          TextButton(
            onPressed: () async {
              final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
              if (pickedFile != null) {
                setState(() {
                  _image = File(pickedFile.path);
                });
              }
              Navigator.of(context).pop();
            },
            child: Row(
              children: [
                Icon(Icons.photo_library),
                SizedBox(width: 8),
                Text('Galería'),
              ],
            ),
          ),
          TextButton(
            onPressed: () async {
              final pickedFile = await ImagePicker().pickImage(source: ImageSource.camera);
              if (pickedFile != null) {
                setState(() {
                  _image = File(pickedFile.path);
                });
              }
              Navigator.of(context).pop();
            },
            child: Row(
              children: [
                Icon(Icons.camera_alt),
                SizedBox(width: 8),
                Text('Cámara'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showEditProductDialog(BuildContext context, Product product) {
    final _nombreController = TextEditingController(text: product.nombre);
    final _precioController = TextEditingController(text: product.precio?.toString());
    final _observacionController = TextEditingController(text: product.observacion);
    final _codigoxController = TextEditingController(text: product.codigox);
    String _categoria = product.idCategoria.toString();
    File? _image;

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            Future<void> _pickImage() async {
              final pickedFile = await showDialog<File>(
                context: context,
                builder: (context) => AlertDialog(
                  title: Text('Seleccionar imagen'),
                  content: Text('Elige una fuente'),
                  actions: [
                    TextButton(
                      onPressed: () async {
                        final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
                        if (pickedFile != null) {
                          setState(() {
                            _image = File(pickedFile.path);
                          });
                        }
                        Navigator.of(context).pop();
                      },
                      child: Row(
                        children: [
                          Icon(Icons.photo_library),
                          SizedBox(width: 8),
                          Text('Galería'),
                        ],
                      ),
                    ),
                    TextButton(
                      onPressed: () async {
                        final pickedFile = await ImagePicker().pickImage(source: ImageSource.camera);
                        if (pickedFile != null) {
                          setState(() {
                            _image = File(pickedFile.path);
                          });
                        }
                        Navigator.of(context).pop();
                      },
                      child: Row(
                        children: [
                          Icon(Icons.camera_alt),
                          SizedBox(width: 8),
                          Text('Cámara'),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            }

            return AlertDialog(
              title: Text('Editar Producto', style: TextStyle(color: Colors.purpleAccent)),
              content: SingleChildScrollView(
                child: Form(
                  key: _editFormKey,
                  child: Column(
                    children: [
                      TextFormField(
                        controller: _nombreController,
                        decoration: InputDecoration(labelText: 'Nombre'),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'El campo nombre es obligatorio';
                          }
                          return null;
                        },
                      ),
                      TextFormField(
                        controller: _precioController,
                        decoration: InputDecoration(labelText: 'Precio'),
                        keyboardType: TextInputType.number,
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                        ],
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'El campo precio es obligatorio';
                          }
                          return null;
                        },
                      ),
                      TextFormField(
                        controller: _observacionController,
                        decoration: InputDecoration(labelText: 'Observación'),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'El campo observación es obligatorio';
                          }
                          return null;
                        },
                      ),
                      TextFormField(
                        controller: _codigoxController,
                        decoration: InputDecoration(labelText: 'Código personalizado'),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'El campo código personalizado es obligatorio';
                          }
                          return null;
                        },
                      ),
                      DropdownButtonFormField<String>(
                        value: _categoria,
                        onChanged: (String? newValue) {
                          setState(() {
                            _categoria = newValue!;
                          });
                        },
                        items: <String>['1', '2']
                            .map<DropdownMenuItem<String>>((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(value == '1' ? 'Arreglo Floral' : 'Otra categoría'),
                          );
                        }).toList(),
                        decoration: InputDecoration(labelText: 'Categoría'),
                      ),
                      SizedBox(height: 16),
                      GestureDetector(
                        onTap: () => _pickImage(),
                        child: _image == null
                            ? Container(
                          width: 100,
                          height: 100,
                          color: Colors.grey[300],
                          child: Icon(Icons.add_a_photo, color: Colors.grey[800]),
                        )
                            : Image.file(
                          _image!,
                          width: 100,
                          height: 100,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: Text('CANCELAR'),
                ),
                ElevatedButton(
                  onPressed: () {
                    if (_editFormKey.currentState!.validate()) {
                      final updatedProduct = product.copyWith(
                        nombre: _nombreController.text,
                        precio: double.tryParse(_precioController.text),
                        observacion: _observacionController.text,
                        codigox: _codigoxController.text,
                        idCategoria: int.parse(_categoria),
                      );
                      con.updateProduct(updatedProduct, _image);
                      Navigator.of(context).pop();
                    }
                  },
                  child: Text('GUARDAR'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.purpleAccent,
                    foregroundColor: Colors.white,
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  void _showAddProductDialog(BuildContext context, InventoryController con) {
    final _nombreController = TextEditingController();
    final _precioController = TextEditingController();
    final _observacionController = TextEditingController();
    final _codigoxController = TextEditingController();
    String _categoria = 'Arreglo Floral';

    File? _image;

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            Future<void> _pickImage() async {
              final pickedFile = await showDialog<File>(
                context: context,
                builder: (context) => AlertDialog(
                  title: Text('Seleccionar imagen'),
                  content: Text('Elige una fuente'),
                  actions: [
                    TextButton(
                      onPressed: () async {
                        final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
                        if (pickedFile != null) {
                          setState(() {
                            _image = File(pickedFile.path);
                          });
                        }
                        Navigator.of(context).pop();
                      },
                      child: Row(
                        children: [
                          Icon(Icons.photo_library),
                          SizedBox(width: 8),
                          Text('Galería'),
                        ],
                      ),
                    ),
                    TextButton(
                      onPressed: () async {
                        final pickedFile = await ImagePicker().pickImage(source: ImageSource.camera);
                        if (pickedFile != null) {
                          setState(() {
                            _image = File(pickedFile.path);
                          });
                        }
                        Navigator.of(context).pop();
                      },
                      child: Row(
                        children: [
                          Icon(Icons.camera_alt),
                          SizedBox(width: 8),
                          Text('Cámara'),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            }

            return AlertDialog(
              title: Text('Nuevo Producto', style: TextStyle(color: Colors.purpleAccent)),
              content: SingleChildScrollView(
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      TextFormField(
                        controller: _nombreController,
                        decoration: InputDecoration(labelText: 'Nombre'),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'El campo nombre es obligatorio';
                          }
                          return null;
                        },
                      ),
                      TextFormField(
                        controller: _precioController,
                        decoration: InputDecoration(labelText: 'Precio'),
                        keyboardType: TextInputType.number,
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                        ],
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'El campo precio es obligatorio';
                          }
                          return null;
                        },
                      ),
                      TextFormField(
                        controller: _observacionController,
                        decoration: InputDecoration(labelText: 'Observación'),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'El campo observación es obligatorio';
                          }
                          return null;
                        },
                      ),
                      TextFormField(
                        controller: _codigoxController,
                        decoration: InputDecoration(labelText: 'Código personalizado'),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'El campo código personalizado es obligatorio';
                          }
                          return null;
                        },
                      ),
                      DropdownButtonFormField<String>(
                        value: _categoria,
                        onChanged: (String? newValue) {
                          setState(() {
                            _categoria = newValue!;
                          });
                        },
                        items: <String>['Arreglo Floral', 'Otra categoría']
                            .map<DropdownMenuItem<String>>((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(value == 'Arreglo Floral' ? 'Arreglo Floral' : 'Otra categoría'),
                          );
                        }).toList(),
                        decoration: InputDecoration(labelText: 'Categoría'),
                      ),
                      SizedBox(height: 16),
                      GestureDetector(
                        onTap: _pickImage,
                        child: _image == null
                            ? Container(
                          width: 100,
                          height: 100,
                          color: Colors.grey[300],
                          child: Icon(Icons.add_a_photo, color: Colors.grey[800]),
                        )
                            : Image.file(
                          _image!,
                          width: 100,
                          height: 100,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: Text('CANCELAR', style: TextStyle(color: Colors.grey)),
                ),
                ElevatedButton(
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      final newProduct = Product(
                        nombre: _nombreController.text,
                        precio: double.tryParse(_precioController.text),
                        observacion: _observacionController.text,
                        codigox: _codigoxController.text,
                        idCategoria: _categoria == 'Arreglo Floral' ? 1 : 2, // Asigna el ID correcto basado en la categoría seleccionada
                        estado: 'ACTIVO',
                      );
                      con.addProduct(newProduct, _image);
                      Navigator.of(context).pop();
                    }
                  },
                  child: Text('GUARDAR'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.purpleAccent,
                    foregroundColor: Colors.white,
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }
}
