class Environment {

  static const String API_URL = "http://192.168.100.103:5000/";
}