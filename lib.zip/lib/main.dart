import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:vernelly_app/src/models/ctrldashboard/ctrldasboard_home.dart';
import 'package:vernelly_app/src/pages/contacts/contacts_page.dart';
import 'package:vernelly_app/src/pages/dashboard/dashboard_page.dart';
import 'package:vernelly_app/src/pages/inventory/products/inventory_products_page.dart';
import 'package:vernelly_app/src/pages/login/login_page.dart';
import 'package:vernelly_app/src/pages/sales/sales_page.dart';
import 'package:vernelly_app/src/pages/settings/settings_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await GetStorage.init();
  await _requestPermissions(); // Solicitar permisos antes de iniciar la app
  runApp(const MyApp());
}

Future<void> _requestPermissions() async {
  await [
    Permission.storage,
    Permission.manageExternalStorage,
  ].request();
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Vernelly',
      debugShowCheckedModeBanner: false,
      initialRoute: _getInitialRoute(),
      getPages: [
        GetPage(name: '/', page: () => LoginPage()),
        GetPage(name: '/models/ctrldashboard', page: () => CtrldasboardHome()),
        GetPage(name: '/pages/dashboard', page: () => DashboardPage()),
        GetPage(name: '/pages/inventory', page: () => InventoryProductsPage()),
        GetPage(name: '/pages/sales', page: () => SalesPage()),
        GetPage(name: '/pages/contacts', page: () => ContactsPage()),
        GetPage(name: '/pages/settings', page: () => SettingsPage())
      ],
      theme: ThemeData(
        primaryColor: Colors.purpleAccent,
        colorScheme: ColorScheme(
          primary: Colors.purpleAccent,
          secondary: Colors.deepPurpleAccent,
          brightness: Brightness.light,
          onPrimary: Colors.red,
          surface: Colors.white,
          onSurface: Colors.black,
          onSecondary: Colors.amber,
          error: Colors.blue,
          onError: Colors.amberAccent,
        ),
      ),
      navigatorKey: Get.key,
    );
  }

  String _getInitialRoute() {
    final token = GetStorage().read('authToken');
    if (token != null) {
      return '/models/ctrldashboard'; // Ruta para la página principal si el usuario está autenticado
    } else {
      return '/'; // Ruta para la página de inicio de sesión si el usuario no está autenticado
    }
  }
}
